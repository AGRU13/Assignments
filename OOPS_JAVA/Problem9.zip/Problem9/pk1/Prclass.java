package pk1;

public class Prclass{
    protected int var;
    public Prclass(int var){
        this.var=var;
    }
};