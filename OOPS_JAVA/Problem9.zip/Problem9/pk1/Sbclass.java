package pk1;

public class Sbclass extends Prclass{
    public Sbclass(int var){
        super(var);
    }
    public int getVar(){
        return var;
    }
};